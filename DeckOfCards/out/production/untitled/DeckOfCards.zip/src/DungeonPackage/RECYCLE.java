package DungeonPackage;

public class RECYCLE {



//        List<Card> cards = new ArrayList<>();
//        for (String rank : ranks){
//            for (String suit: suits){
//                cards.add(new Card(rank, suit));
//
//            }
//        }
//        for (int i = 0; i < cards.size(); i++){
//            if (i % 4 == 0){
//                System.out.println();
//            }
//            System.out.println(cards.get(i));
//        }
//        System.out.println("------------------------------------------");
//
//        Collections.shuffle(cards);
//        for (int i = 0; i < cards.size(); i++){
//            System.out.println(cards.get(i));
//
//        }
//        System.out.println("------------------------------------------");
//
//
//        List<Card> cards2 = new ArrayList<>();
//        for (int j = 0; j < suits.length; j++){
//            for (int x = 0; x < ranks.length; x++){
//                cards2.add(new Card(ranks[x], suits[j]));
//            }
//        }
//        System.out.println(cards2.size());
//        for (int i = 0; i < cards2.size(); i++){
//            if (i % 13 == 0){
//                System.out.println();
//            }
//            System.out.println(cards2.get(i));
//
//        }



//        Map<String, Integer> ranksMap = new HashMap<>();
//        Map<String, Integer> suitsMap = new HashMap<>();
//        for (int i = 0; i < ranks.length; i++){
//            ranksMap.put(ranks[i], i);
//        }
//        for (int i = 0; i < suits.length; i++){
//            suitsMap.put(suits[i], i);
//        }
//        System.out.println(ranksMap);
//        System.out.println(suitsMap);
//
//
//        for (int i = 0; i < cards.size(); i++){
//            for (int j = 0; j < cards.size(); j++){
//                if (i == ranksMap.get("TWO")){
//                    ranksDeck.add(new Card("TWO", suits[i]));
//                }
//            }
//        }



















//        Map<Integer, String> cardMapIF = new HashMap<>();
//        Map<String, Integer> cardMapSF = new HashMap<>();
//        for (int i = 0; i < 4; i++){
//            cardMapIF.put(i+1, suits[i]);
//            cardMapSF.put(suits[i], i+1);
//        }
//
//        System.out.println(cardMapIF);
//        System.out.println(cardMapSF);
//
//
//        for (int i = 0; i < cardsRandomlySorted.size(); i++){
//
//        }

//        for (Map.Entry<Integer, String> pair : cardMap.entrySet()) {
//            System.out.println(pair.getKey());
//        }
//
//        List<Card> cardsSortedByRank = new ArrayList<>();
//        for (int i = 0; i < cardsRandomlySorted.size(); i++){
//            for (Map.Entry<Integer, String> pair : cardMap.entrySet()) {
//               if (i == pair.getKey()){
//                   cardsSortedByRank.add(new Card("Hello", "World"));
//               }
//            }
//            System.out.println(cardsSortedByRank);
//        }


//        System.out.println(cards);
//
//        System.out.println(cards.size());
//        System.out.println();
//
//        for (int i = 0; i < cards.size(); i++){
//            if (i % 4 == 0){
//                System.out.println();
//            }
//            System.out.println(cards.get(i));
//
//        }
//
//        Scanner scanner = new Scanner(System.in);
//        System.out.println("print 1 out");
//        int input = scanner.nextInt();
//        System.out.println(cards.size());
//
//





//
//        System.out.println("----------------------------------");
//
//

//        Collections.shuffle(cards);
//
//
//
//        for (int i = 0; i < cards.size(); i++){
//            if (i % 4 == 0){
//                System.out.println();
//            }
//            System.out.println(cards.get(i));
//
//        }

}
